import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-corrections.ts';
import '@/ai/flows/transcribe-audio.ts';